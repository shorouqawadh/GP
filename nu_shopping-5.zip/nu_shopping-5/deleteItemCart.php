<?php
	
	include("admin/classes/DB.php");
	include("admin/classes/Item.php");
	include("admin/classes/Cart.php");
	$db  = new DB();
	$cart  = new Cart();
	
	
	 
	$cart_item_id = isset($_POST["cart_item_id"]) ? $_POST["cart_item_id"] : "0";  
	
	if($cart->deleteItemCart($cart_item_id) )
	{
		echo "ok";
	}
	
?>
